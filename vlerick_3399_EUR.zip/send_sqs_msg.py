"""Send ceeb code and url to a queue an trigger lambda function"""
import boto3
import botocore


def send_message(queue_name):
    """Send message to a queue"""
    msg = {"3399_EUR": "https://www.vlerick.com/en/programmes/management-programmes"}
    return